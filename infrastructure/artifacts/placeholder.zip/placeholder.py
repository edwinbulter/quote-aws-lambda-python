def handler(event, context):
    return {"statusCode": 503, "body": "placeholder - run scripts/deploy_code.sh to deploy the real app"}
